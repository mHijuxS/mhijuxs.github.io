---
title: Local File Inclusion (LFI)
layout: default
permalink: /theory/web/lfi/
---

# Local File Inclusion (LFI)

LFI allows attackers to include files from the server via parameters.

## 🧪 Common Payloads

- `?file=../../../../etc/passwd`
- `%00` null byte injection (older systems)

## 🧰 Detection

```bash
curl 'http://site/page?file=../../../../etc/passwd'
```

## 📚 References

- https://owasp.org/www-community/attacks/Local_File_Inclusion
