---
title: Kerberos Protocol
layout: default
permalink: /theory/protocols/kerberos/
---

# Kerberos Protocol Overview

Kerberos is a ticket-based authentication protocol used in both Windows and some Linux systems.

## 🔹 Flow

1. AS-REQ / AS-REP
2. TGS-REQ / TGS-REP
3. AP-REQ / AP-REP

## 📚 References

- https://learn.microsoft.com/en-us/windows-server/security/kerberos/
