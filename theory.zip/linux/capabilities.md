---
title: Linux Capabilities
layout: default
permalink: /theory/linux/capabilities/
---

# Linux Capabilities

Linux capabilities allow finer-grained control over root-level privileges for binaries.

## 🔧 Common Exploits

- Abuse of `cap_setuid`, `cap_setgid` for privilege escalation
- Searching for files with capabilities: `getcap -r / 2>/dev/null`

```bash
getcap -r / 2>/dev/null
```

## 📚 References

- https://man7.org/linux/man-pages/man7/capabilities.7.html
