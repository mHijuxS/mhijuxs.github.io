---
title: Sudo Privilege Escalation
layout: default
permalink: /theory/linux/sudo/
---

# Sudo Privilege Escalation

Misconfigured `sudo` can allow privilege escalation.

## 🔧 Common Findings

- NOPASSWD for dangerous commands
- `sudo -l` to list allowed commands

```bash
sudo -l
```

## 📚 References

- https://gtfobins.github.io/
